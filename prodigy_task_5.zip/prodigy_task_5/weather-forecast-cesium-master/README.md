<h1>Simulation<br/>wheather forecast app</h1>
<h2>based on <a href="https://cesiumjs.org/">Cesium Js</a>, a free alternative to Google Earth</h2>
<p>Since the Google Earth API has been deprecated and not supported after 2016, Cesium can become a good alternatives.</p>
<p>This prototype is very simple, but it will be not difficult to implement a more complex application with the use of real data supplied by free/paied weather service.</p>
<p>For example, <a href="http://openweathermap.org/">OpenWeatherMap</a> provides current weather data (available in JSON, XML) for any location on Earth</p>
<font size="4"><a href="http://pafavero.github.io/weather-forecast-cesium/" target="_blank" >http://pafavero.github.io/weather-forecast-cesium/</a></font>
<a href="https://cdn.rawgit.com/pafavero/weather-forecast-cesium/master/index.html" target="_blank" >
    <img title="show preview" src="custom/img/screenshot.JPG" />
</a>
<p>
    <font size="4"><a href="http://pafavero.github.io/weather-forecast-cesium/" target="_blank" >Show preview</a></font>
</p>  
